package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.CustomFieldCreateRequest;
import com.example.managementservice.exchange.request.CustomFieldUpdateRequest;
import com.example.managementservice.exchange.request.FieldRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.CustomFieldResponse;
import com.example.managementservice.exchange.response.PaginatedResponse;
import com.example.managementservice.exchange.response.ProjectFieldResponse;
import com.example.managementservice.model.CustomField;
import com.example.managementservice.service.impl.CustomFieldServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/custom-fields")
@RequiredArgsConstructor
@Tag(name = "Custom Field controller", description = "Controller for managing custom fields")
public class CustomFieldController {

    private final CustomFieldServiceImpl customFieldService;

    @PostMapping
    @Operation(summary = "Create a new custom field", description = "Creates a new custom field with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createCustomField(@Valid @RequestBody CustomFieldCreateRequest createRequest) {
        customFieldService.createCustomField(createRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseHandler<>(true, "Custom field created successfully", null));
    }

    @GetMapping
    @Operation(summary = "Get all custom fields", description = "Retrieves a paginated list of all custom fields.")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<CustomFieldResponse>>> getAllCustomFieldResponse(@RequestParam int page, @RequestParam int limit) {
        PaginatedResponse<CustomFieldResponse> customFields = customFieldService.getAllCustomFields(page, limit);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom fields retrieved successfully", customFields));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get custom field by ID", description = "Retrieves a specific custom field by its ID.")
    public ResponseEntity<ApiResponseHandler<CustomFieldResponse>> getCustomFieldById(@PathVariable String id) {
        CustomFieldResponse customField = customFieldService.getCustomFieldById(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom field retrieved successfully", customField));
    }

    @PutMapping
    @Operation(summary = "Update an existing custom field", description = "Updates the details of an existing custom field.")
    public ResponseEntity<ApiResponseHandler<CustomField>> updateCustomField(@RequestBody CustomFieldUpdateRequest updateRequest) {
        customFieldService.updateCustomField(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom field updated successfully", null));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a custom field", description = "Deletes the custom field with the given ID.")
    public ResponseEntity<ApiResponseHandler<String>> deleteCustomField(@PathVariable String id) {
        customFieldService.deleteCustomField(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom field deleted successfully", null));
    }

    @GetMapping("/project/{projectId}")
    @Operation(summary = "Get custom fields by project ID", description = "Retrieves a list of custom fields associated with a specific project.")
    public ResponseEntity<ApiResponseHandler<ProjectFieldResponse>> getAllCustomFieldsByProjectId(@PathVariable UUID projectId) {
        ProjectFieldResponse customFields = customFieldService.getCustomFieldsByProjectId(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom fields retrieved successfully", customFields));
    }

    @GetMapping("work-type/{workTypeId}")
    @Operation(summary = "Get custom fields by work type", description = "Retrieves a list of custom fields associated with a specific work type.")
    public ResponseEntity<ApiResponseHandler<List<CustomFieldResponse>>> getCustomFieldsByWorkType(@PathVariable String workTypeId) {
        List<CustomFieldResponse> customFields = customFieldService.getCustomFieldsByWorkType(workTypeId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom fields retrieved successfully", customFields));
    }

    @PutMapping("/work-type/order")
    @Operation(summary = "Update custom field order based on work type", description = "Updates the order of custom fields based on the specified work type.")
    public ResponseEntity<ApiResponseHandler<Object>> updateCustomFieldOrderBasedOnWorkType(@RequestBody FieldRequest updateRequest) {
        customFieldService.updateCustomFieldOrderBasedOnWorkType(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom field order updated successfully", null));
    }
}