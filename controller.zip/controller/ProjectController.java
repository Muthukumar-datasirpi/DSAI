package com.example.managementservice.controller;

import com.example.managementservice.config.ActivityLogger;
import com.example.managementservice.exchange.request.ProjectConfigUpdateRequest;
import com.example.managementservice.exchange.request.ProjectConfigsRequest;
import com.example.managementservice.exchange.request.ProjectRequest;
import com.example.managementservice.exchange.request.UpdateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.PaginatedResponse;
import com.example.managementservice.exchange.response.ProjectDetails;
import com.example.managementservice.model.Project;
import com.example.managementservice.service.ProjectService;
import com.example.managementservice.utils.AppConstants;
import com.example.managementservice.utils.TokenUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/projects")
@Tag(name = "Project Management", description = "APIs for managing projects")
public class  ProjectController {

    private static final Logger log = LoggerFactory.getLogger(ProjectController.class);
    private final ProjectService projectService;
    private final ActivityLogger activityLogger;
    private final TokenUtil tokenUtil;

    @PostMapping("/create")
    @Operation(summary = "Create a new project", description = "Create a new project with the provided details")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Project successfully created"),
            @ApiResponse(responseCode = "400", description = "Invalid input provided")
    })
    public ResponseEntity<ApiResponseHandler<Object>> createProject(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @RequestBody @Valid ProjectRequest projectRequest,
            @AuthenticationPrincipal Jwt jwt) {

        Project project =  projectService.createProject(projectRequest, jwt);
        String entityName = projectRequest.getClass().getSimpleName().replaceAll("(Request|DTO|Response)$", "");
        activityLogger.logActivity(null, project, jwt ,entityName);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponseHandler<>(true, "Project created successfully"));
    }

    @GetMapping("/list")
    @Operation(
            summary = "Get all projects",
            description = "Retrieve a paginated list of all available projects with optional issues"
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "List retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid page, size, or sort parameters")
    })
    public ResponseEntity<ApiResponseHandler<Object>> getAllProjects(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,

            @Parameter(description = "Page number (0-based)", example = "0")
            @RequestParam(defaultValue = "0") int page,

            @Parameter(description = "Number of records per page", example = "10")
            @RequestParam(defaultValue = "10") int size,

            @Parameter(description = "Field to sort by", example = "createdAt")
            @RequestParam(defaultValue = "createdAt") String sortBy,

            @Parameter(description = "Sort direction ('asc' or 'desc')", example = "asc",
                    schema = @Schema(allowableValues = {"asc", "desc"}))
            @RequestParam(defaultValue = "asc") String direction,

            @Parameter(description = "Search term to filter projects by name", example = "Project A")
            @RequestParam(required = false) String search,

            @Parameter(description = "Include issues with projects", example = "false")
            @RequestParam(defaultValue = "false") boolean includeIssues,

            @RequestParam(required = false) Boolean isService,

            @AuthenticationPrincipal Jwt jwt
    ) {
        Sort.Direction sortDirection = direction.equalsIgnoreCase("desc") ?
                Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        Object result = includeIssues
                ? projectService.getAllProjectsWithIssues(pageable, search, isService)
                : projectService.getAllProjects(pageable, jwt, search, isService);

        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Projects retrieved successfully", result));
    }


    @GetMapping("/by-ids")
    @Operation(summary = "Get projects by IDs", description = "Retrieve details of projects by their IDs")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Projects retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "Projects not found")
    })
    public ResponseEntity<ApiResponseHandler<List<Map<String, Object>>>> getProjectsByIds(
            @RequestParam List<UUID> ids,
            @AuthenticationPrincipal Jwt jwt) {

        List<Map<String, Object>> projects = projectService.getProjectsByIds(ids, jwt);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Projects retrieved successfully", projects));
    }

    @GetMapping("/{projectId}")
    @Operation(summary = "Get project by ID", description = "Retrieve a project by its ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Project retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "Project not found")
    })
    public ResponseEntity<ApiResponseHandler<ProjectDetails>> getProjectById(
            @PathVariable UUID projectId) {

        ProjectDetails project = projectService.getProjectDetailsById(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project retrieved successfully", project));
    }

    @PutMapping("/update/{id}")
    @Operation(summary = "Update a project", description = "Update the details of an existing project")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Project updated successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input provided"),
            @ApiResponse(responseCode = "404", description = "Project not found")
    })
    public ResponseEntity<ApiResponseHandler<Object>> updateProject(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @PathVariable UUID id,
            @RequestBody @Valid ProjectRequest projectRequest,
            @AuthenticationPrincipal Jwt jwt) {

        UpdateRequest<Project> result = projectService.updateProject(id, projectRequest, jwt);
        String entityName = projectRequest.getClass().getSimpleName().replaceAll("(Request|DTO|Response)$", "");
        activityLogger.logActivity(result.getOldValue(), result.getUpdatedValue(), jwt, entityName);
        return ResponseEntity.ok(new ApiResponseHandler<Object>(true, "Project updated successfully"));
    }

    @DeleteMapping("/delete/{id}")
    @Operation(summary = "Delete a project", description = "Remove a project from the system")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Project deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Project not found")
    })
    public ResponseEntity<ApiResponseHandler<Object>> deleteProject(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @PathVariable UUID id,
            @AuthenticationPrincipal Jwt jwt) {


        Project project = projectService.deleteProject(id, jwt);
        String entityName = project.getClass().getSimpleName().replaceAll("(Request|DTO|Response)$", "");
        activityLogger.logActivity(project, null, jwt, entityName);
        return ResponseEntity.ok(new ApiResponseHandler<Object>(true, "Project deleted successfully"));
    }

    @GetMapping("/search")
    @Operation(summary = "Search for projects", description = "Search for projects with pagination")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Projects retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input provided")
    })
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<ProjectDetails>>> searchProjects(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir
    ) {
        Sort.Direction direction = sortDir.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));

        PaginatedResponse<ProjectDetails> projects = projectService.searchProjects(query, pageable);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Projects retrieved successfully", projects));
    }

    @Operation(summary = "Get project configurations", description = "Fetch status and category configurations for a given project")
    @GetMapping("/project-configs")
    public ResponseEntity<ApiResponseHandler<List<Map<String, Object>>>> getProjectStatus(@RequestParam UUID projectId) {
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Projects Configs found successfully", projectService.getProjectStatus(projectId)));
    }

    @Operation(summary = "Add Project Config", description = "Adds a new configuration to the project.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project Config added successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("/project-configs")
    public ResponseEntity<ApiResponseHandler<Object>> addProjectConfigs(
            @RequestBody ProjectConfigsRequest request) {
        projectService.addProjectConfig(request);
        return ResponseEntity.ok(new ApiResponseHandler<Object>(true, "Project Configs added successfully"));
    }

    @Operation(summary = "Get Project By Project Lead", description = "Retrieves projects by project lead.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Projects retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters")
    })
    @GetMapping("/project-lead")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<ProjectDetails>>> getProjectByProjectLead(@RequestParam String ProjectLead,
                                                                                                         @RequestParam(defaultValue = "0") int page,
                                                                                                         @RequestParam(defaultValue = "10") int size,
                                                                                                         @RequestParam(defaultValue = "createdAt") String sortBy,
                                                                                                         @RequestParam(defaultValue = "asc") String sortDir) {
        log.info("Getting projects by project lead: {}", ProjectLead);
        Sort.Direction direction = sortDir.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));

        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Projects retrieved successfully", projectService.getProjectByProjectLead(ProjectLead, pageable)));
    }

    @Operation(summary = "Update Project Config", description = "Updates an existing configuration in the project.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project Config updated successfully"),
            @ApiResponse(responseCode = "404", description = "Config not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PutMapping("/project-configs")
    public ResponseEntity<ApiResponseHandler<Object>> updateProjectConfig(@RequestParam UUID configId,
                                                                  @RequestBody ProjectConfigsRequest request) {
        projectService.updateProjectConfig(configId, request);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project Config updated successfully"));
    }

    @Operation(summary = "Delete Project Config", description = "Removes a configuration from the project.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project Config deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Config not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @DeleteMapping("/project-configs")
    public ResponseEntity<ApiResponseHandler<Object>> deleteProjectConfig(@RequestParam UUID projectId,
                                                                  @RequestParam UUID configId) {
        projectService.deleteProjectConfig(projectId, configId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project Config deleted successfully"));
    }

    @Operation(summary = "Update Project Config Sort Orders", description = "Updates the sort order of existing project configs.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project Configs updated successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PutMapping("/status/project-configs")
    public ResponseEntity<ApiResponseHandler<Object>> updateProjectConfigs(@RequestBody ProjectConfigUpdateRequest request) {
        projectService.updateProjectConfigs(request);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project Configs updated successfully"));
    }

    @DeleteMapping("/project-configs/column-delete")
    public ResponseEntity<ApiResponseHandler<Object>> safeDeleteStatusColumn(
            @RequestParam UUID projectId,
            @RequestParam String oldStatusId,
            @RequestParam String newStatusId) {

        projectService.reassignIssuesAndDeleteStatus(projectId, oldStatusId, newStatusId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Status column deleted and issues reassigned successfully"));
    }

    @GetMapping("/recently-worked")
    public ResponseEntity<ApiResponseHandler<List<Map<String, Object>>>> getTop3RecentlyWorkedProjects() {
        String userId=tokenUtil.getAppUserId();
        List<Project> projects = projectService.getTop3RecentlyWorkedProjects(userId);

        List<Map<String, Object>> response = projects.stream().map(project -> {
            Map<String, Object> map = new HashMap<>();
            map.put("projectId", project.getProjectId());
            map.put("projectName", project.getTitle());
            map.put("projectKey", project.getProjectKey());
            map.put("projectCategory", project.getProjectCategory().getTitle());
            return map;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(
                new ApiResponseHandler<>(true, "Top 3 recently worked projects fetched successfully", response)
        );
    }
}