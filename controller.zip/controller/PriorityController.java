package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.PriorityRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.model.Priority;
import com.example.managementservice.service.PriorityService;
import com.example.managementservice.utils.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/priority")
@Tag(name = "Priority Management", description = "APIs for managing workflow priorities")
public class PriorityController {

    private final PriorityService priorityService;

    @Operation(summary = "Create a new Priority",
            description = "Creates a new workflow priority in the system")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Priority created successfully",
                    content = @Content(schema = @Schema(implementation = ApiResponseHandler.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input provided"),
            @ApiResponse(responseCode = "409", description = "Priority already exists")
    })
    @PostMapping("/create")
    public ResponseEntity<ApiResponseHandler<Object>> createPriority(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @Valid @RequestBody PriorityRequest priorityRequest, @AuthenticationPrincipal Jwt jwt) {
        priorityService.createPriority(priorityRequest, jwt);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(new ApiResponseHandler<>(true, "Priority created successfully"));
    }

    @Operation(
            summary = "Get all priorities",
            description = "Retrieves a paginated list of all priorities"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved the list of priorities"),
            @ApiResponse(responseCode = "400", description = "Invalid page, size or sort parameters"),
            @ApiResponse(responseCode = "404", description = "No priorities found")
    })
    @GetMapping
    public ResponseEntity<ApiResponseHandler<Map<String, Object>>> getAllPriorities(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,

            @Parameter(description = "Page number (0-based)", example = "0")
            @RequestParam(defaultValue = "0") int page,

            @Parameter(description = "Number of records per page", example = "10")
            @RequestParam(defaultValue = "10") int size,

            @Parameter(description = "Field to sort by", example = "createdAt")
            @RequestParam(defaultValue = "createdAt") String sortBy,

            @Parameter(description = "Sort direction ('asc' or 'desc')", example = "asc",
                    schema = @Schema(allowableValues = {"asc", "desc"}))
            @RequestParam(defaultValue = "asc") String direction
    ) {
        Sort.Direction sortDirection = direction.equalsIgnoreCase("desc") ?
                Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        return ResponseEntity.ok(new ApiResponseHandler<>(true,
                "Priorities retrieved successfully", priorityService.getAllPriorities(pageable)));
    }

    @Operation(summary = "Get Priority by ID",
            description = "Retrieves a specific priority by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Priority retrieved successfully",
                    content = @Content(schema = @Schema(implementation = ApiResponseHandler.class))),
            @ApiResponse(responseCode = "404", description = "Priority not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponseHandler<Priority>> getPriorityById(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @Parameter(description = "Priority ID", required = true)
            @PathVariable UUID id) {
        Priority priority = priorityService.getPriorityById(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(
                true,
                "Priority retrieved successfully",
                priority));
    }

    @Operation(summary = "Update Priority", description = "Updates an existing priority by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Priority updated successfully", content = @Content(schema = @Schema(implementation = ApiResponseHandler.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input provided"),
            @ApiResponse(responseCode = "404", description = "Priority not found")
    })
    @PutMapping(value = "/{id}")
    public ResponseEntity<ApiResponseHandler<Object>> updatePriority(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @Parameter(description = "Priority ID", required = true)
            @PathVariable UUID id,
            @Valid @RequestBody PriorityRequest priorityRequest, @AuthenticationPrincipal Jwt jwt) {
        priorityService.updatePriority(id, priorityRequest, jwt);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Priority updated successfully"));
    }

    @Operation(summary = "Delete Priority", description = "Deletes a priority by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Priority deleted successfully", content = @Content(schema = @Schema(implementation = ApiResponseHandler.class))),
            @ApiResponse(responseCode = "404", description = "Priority not found"),
            @ApiResponse(responseCode = "409", description = "Priority cannot be deleted as it's in use")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponseHandler<Object>> deletePriority(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @Parameter(description = "Priority ID", required = true)
            @PathVariable UUID id, @AuthenticationPrincipal Jwt jwt) {
        priorityService.deletePriority(id, jwt);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Priority deleted successfully"));
    }
}