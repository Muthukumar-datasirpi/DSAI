package com.example.managementservice.controller;

import com.example.managementservice.exchange.response.*;
import com.example.managementservice.service.impl.SprintBacklogServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/sprint-backlog")
@RequiredArgsConstructor
@Tag(name = "Sprint Backlog Controller", description = "Controller for managing sprint backlogs")
public class SprintBacklogController {

    private final SprintBacklogServiceImpl sprintBacklogService;

    @GetMapping
    @Operation(summary = "Get sprint backlogs", description = "Retrieves all sprint backlogs for a specific project with pagination options.")
    public ResponseEntity<ApiResponseHandler<SprintBacklogResponse>> getSprintBacklogs(@RequestParam UUID projectId, @RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "10") int size) {
        SprintBacklogResponse response = sprintBacklogService.getSprintBacklogs(projectId, page, size);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint backlogs fetched successfully", response));
    }

    @GetMapping("/{projectId}")
    @Operation(summary = "Get sprint tickets", description = "Retrieves all tickets for a specific sprint in a project with pagination and sorting options.")
    public ResponseEntity<ApiResponseHandler<SprintBacklogResponse>> getSprintTickets(@PathVariable UUID projectId, @RequestParam String sprintId, @RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "10") int size, @RequestParam(defaultValue = "createdAt") String sortBy, @RequestParam(defaultValue = "desc") String sortDirection ) {
        SprintBacklogResponse response = sprintBacklogService.getSprintTickets(projectId, sprintId, page, size, sortBy, sortDirection);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint tickets fetched successfully", response));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete sprint backlog", description = "Deletes the sprint backlog with the specified ID.")
    public ResponseEntity<ApiResponseHandler<Object>> deleteSprintBacklog(@PathVariable String id) {
        sprintBacklogService.deleteSprintBacklog(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint backlog deleted successfully", null));
    }

    @PutMapping("/{id}/assign")
    @Operation(summary = "Assign backlog to sprint", description = "Assigns a backlog item to the specified sprint.")
    public ResponseEntity<ApiResponseHandler<Object>> assignBacklogToSprint(@PathVariable UUID id, @RequestParam String sprintId) {
        sprintBacklogService.assignBacklogToSprint(id, sprintId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Backlog assigned to sprint successfully"));
    }

    @PutMapping("/{id}/unassign")
    @Operation(summary = "Unassign backlog from sprint", description = "Unassigns a backlog item from the specified sprint.")
    public ResponseEntity<ApiResponseHandler<Object>> unassignBacklogFromSprint(@PathVariable UUID id) {
        sprintBacklogService.unassignBacklogFromSprint(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Backlog unassigned from sprint successfully"));
    }
}