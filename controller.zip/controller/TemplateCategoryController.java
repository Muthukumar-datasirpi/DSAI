package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.TemplateCategoryCreateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.PaginatedResponse;
import com.example.managementservice.exchange.response.TemplateCategoryResponse;
import com.example.managementservice.exchange.request.TemplateCategoryUpdateRequest;
import com.example.managementservice.service.impl.TemplateCategoryServiceImpl;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/template-categories")
@RequiredArgsConstructor
@Tag(name = "Template Category Controller", description = "Controller for managing template categories")
public class TemplateCategoryController {

    private final TemplateCategoryServiceImpl templateCategoryService;

    @PostMapping
    @Operation(summary = "Create a new template category", description = "Creates a new template category with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createTemplateCategory(@Valid @RequestBody TemplateCategoryCreateRequest createRequest) {
        templateCategoryService.createTemplateCategory(createRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Template category created successfully", null));
    }

    @GetMapping
    @Operation(summary = "Get all template categories", description = "Retrieves a paginated list of all template categories.")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<TemplateCategoryResponse>>> getAllTemplateCategories(@RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "20") int limit) {
        PaginatedResponse<TemplateCategoryResponse> templateCategories = templateCategoryService.getAllTemplateCategories(page, limit);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Fetched all template categories", templateCategories));
    }

    @PutMapping
    @Operation(summary = "Update an existing template category", description = "Updates the details of an existing template category.")
    public ResponseEntity<ApiResponseHandler<Object>> updateTemplateCategory(@Valid @RequestBody TemplateCategoryUpdateRequest updateRequest) {
        templateCategoryService.updateTemplateCategory(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Template category updated successfully", null));
    }

    //TODO: Once the basic implementation is done, add a check to ensure that only custom template categories can be deleted
    @DeleteMapping("/{id}")
    @Hidden
    public ResponseEntity<ApiResponseHandler<Object>> deleteCustomTemplateCategory(@PathVariable String id) {
        templateCategoryService.deleteCustomTemplateCategory(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Template category deleted successfully", null));
    }
}