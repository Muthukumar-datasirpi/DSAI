package com.example.managementservice.controller;

import com.example.managementservice.model.MenuAccess;
import com.example.managementservice.service.MenuAccessService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/menu-access")
@RequiredArgsConstructor
@Tag(name = "Menu Access", description = "API for managing menu access")
public class MenuAccessController {

    private final MenuAccessService menuAccessService;

    @PostMapping
    @Operation(summary = "Create Menu Access", description = "Creates a new menu access entry")
    public ResponseEntity<MenuAccess> createMenuAccess(@RequestBody MenuAccess menuAccess) {
        return ResponseEntity.ok(menuAccessService.createMenuAccess(menuAccess));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get Menu Access", description = "Fetches a menu access entry by ID")
    public ResponseEntity<MenuAccess> getMenuAccess(@PathVariable String id) {
        return ResponseEntity.ok(menuAccessService.getMenuAccess(id));
    }

    @GetMapping
    @Operation(summary = "Get All Menu Access", description = "Fetches all menu access entries")
    public ResponseEntity<List<MenuAccess>> getAllMenuAccess() {
        return ResponseEntity.ok(menuAccessService.getAllMenuAccess());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update Menu Access", description = "Updates an existing menu access entry")
    public ResponseEntity<MenuAccess> updateMenuAccess(@PathVariable String id, @RequestBody MenuAccess menuAccess) {
        return ResponseEntity.ok(menuAccessService.updateMenuAccess(id, menuAccess));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete Menu Access", description = "Deletes a menu access entry by ID")
    public ResponseEntity<Void> deleteMenuAccess(@PathVariable String id) {
        menuAccessService.deleteMenuAccess(id);
        return ResponseEntity.noContent().build();
    }
}