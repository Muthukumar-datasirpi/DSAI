package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.CreateTicketRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.FormResponse;
import com.example.managementservice.exchange.response.IssueResponse;
import com.example.managementservice.exchange.response.PaginatedResponse;
import com.example.managementservice.service.impl.TicketServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/tickets")
@RequiredArgsConstructor
@Tag(name = "Ticket Controller", description = "Controller for managing tickets")
public class TicketController {

    private final TicketServiceImpl ticketService;

    @PostMapping("/{requestTypeId}")
    @Operation(summary = "Create a new ticket", description = "Creates a new ticket for the specified request type")
    public ResponseEntity<ApiResponseHandler<Object>> createTicket(@PathVariable String requestTypeId, @RequestParam(required = false) String categoryId, @RequestBody CreateTicketRequest request) {
        ticketService.createTicket(requestTypeId, categoryId, request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponseHandler<>(true, "Ticket created successfully"));
    }

    @GetMapping("/{ticketId}/details")
    @Operation(summary = "Get ticket details by ID", description = "Fetches the details of a ticket by its ID")
    public ResponseEntity<ApiResponseHandler<FormResponse>> getTicketById(@PathVariable UUID ticketId){
        FormResponse formResponse = ticketService.getTicketById(ticketId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Ticket details Fetched successfully", formResponse));
    }

    @GetMapping
    @Operation(summary = "Get all tickets", description = "Fetches all tickets with pagination and optional search")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<FormResponse>>> getUserTickets(@RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "10") int size, @RequestParam String userId, @RequestParam UUID projectId){
        PaginatedResponse<FormResponse> userTickets = ticketService.getUserTickets(page, size, userId, projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User Tickets retrieved Successfully", userTickets));
    }

    @GetMapping("/assigned")
    @Operation(summary = "Get all assigned tickets", description = "Fetches all tickets assigned to a specific user in a project")
    public ResponseEntity<ApiResponseHandler<List<IssueResponse>>> getAllAssignedTickets(@RequestParam String userId, @RequestParam UUID projectId) {
        List<IssueResponse> assignedTickets = ticketService.getAllAssignedTickets(userId, projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Assigned Tickets retrieved Successfully", assignedTickets));
    }
}