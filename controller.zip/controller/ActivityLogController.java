package com.example.managementservice.controller;

import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.model.ActivityLog;
import com.example.managementservice.service.ActivityLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/api/v1/activity-logs")
@Tag(name = "Activity Log", description = "Activity Log APIs")
@RequiredArgsConstructor
public class ActivityLogController {

    private final ActivityLogService activityLogService;

    @Operation(summary = "Get logs by issue ID", description = "Retrieves activity logs for a specific issue")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Logs fetched successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "404", description = "Issue not found")
    })
    @GetMapping("/{issueId}")
    public ResponseEntity<ApiResponseHandler<Page<ActivityLog>>> getLogsByIssueId(@Parameter (description = "Issue ID", required = true) @PathVariable String issueId,
                                                               @Parameter(description = "Page number (0-based)", example = "0") @RequestParam(defaultValue = "0") int page,
                                                               @Parameter(description = "Number of records per page", example = "10") @RequestParam(defaultValue = "10") int size,
                                                               @Parameter(description = "Field to sort by", example = "userId") @RequestParam(defaultValue = "userId") String sortBy,
                                                               @Parameter(description = "Sort direction ('asc' or 'desc')", example = "asc", schema = @Schema(allowableValues = {"asc", "desc"})) @RequestParam(defaultValue = "desc") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        Page<ActivityLog> response = activityLogService.getLogsByIssueId(issueId, pageable);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Logs fetched by issue successfully", response));
    }

    @Operation(summary = "Get logs by project ID", description = "Retrieves activity logs for a specific project")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Logs fetched successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error"),
            @ApiResponse(responseCode = "404", description = "Project not found")
    })
    @GetMapping("/project/{projectId}")
    public ResponseEntity<ApiResponseHandler<Page<ActivityLog>>> getLogsByProjectId(@Parameter (description = "Project ID", required = true) @PathVariable String projectId,
                                                                 @Parameter(description = "Page number (0-based)", example = "0") @RequestParam(defaultValue = "0") int page,
                                                                 @Parameter(description = "Number of records per page", example = "10") @RequestParam(defaultValue = "10") int size,
                                                                 @Parameter(description = "Field to sort by", example = "userId") @RequestParam(defaultValue = "userId") String sortBy,
                                                                 @Parameter(description = "Sort direction ('asc' or 'desc')", example = "asc", schema = @Schema(allowableValues = {"asc", "desc"})) @RequestParam(defaultValue = "desc") String direction) {

        Sort.Direction sortDirection = direction.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

        Page<ActivityLog> response = activityLogService.getLogsByProjectId(projectId, pageable);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Logs fetched by project successfully", response));
    }
}