package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.AssignProjectRequest;
import com.example.managementservice.exchange.request.ProjectUserRolesRequest;
import com.example.managementservice.exchange.request.RoleRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.UserMenuItemPermissionResponse;
import com.example.managementservice.service.UserRoleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
@Tag(name = "User Role Management", description = "APIs for managing user roles")
public class UserRoleController {

    private final UserRoleService userRoleService;

    @PostMapping("/{userId}/roles/{roleId}")
    @Operation(summary = "Assign role to user", description = "Assigns a specific role to a user.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Role assigned successfully"),
            @ApiResponse(responseCode = "400", description = "User already has this role"),
            @ApiResponse(responseCode = "404", description = "Role not found")
    })
    public ResponseEntity<ApiResponseHandler> assignRoleToUser(@PathVariable String userId,
                                                               @PathVariable UUID roleId,
                                                               @RequestParam(required = false) UUID projectId) {
        userRoleService.assignUserRole(userId, roleId, projectId);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponseHandler(true, "Role assigned successfully"));
    }

    @PostMapping("/assign-user-project")
    @Operation(summary = "Assign user to project", description = "Assigns a user to a project.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User assigned to project successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload"),
            @ApiResponse(responseCode = "404", description = "Project not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<ApiResponseHandler> assignUserToProject(@Valid @RequestBody AssignProjectRequest request, @AuthenticationPrincipal Jwt jwt) {
        userRoleService.assignUserToProject(request, jwt);
        return ResponseEntity.ok(new ApiResponseHandler(true, "User assigned to project successfully."));
    }

    @PostMapping("/roles/assign")
    @Operation(summary = "Assign role to user in project", description = "Assigns a specified role to a user within a project.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Role assigned successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload"),
            @ApiResponse(responseCode = "404", description = "Project or role not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<ApiResponseHandler> assignRoleToUserInProject(@Valid @RequestBody ProjectUserRolesRequest request) {
        userRoleService.assignProjectRole(request);
        return ResponseEntity.ok(new ApiResponseHandler(true, "Role assigned successfully for project and user."));
    }

    @DeleteMapping("/{userId}/roles/{roleId}")
    @Operation(summary = "Remove role from user", description = "Removes a specific role from a user.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Role removed successfully"),
            @ApiResponse(responseCode = "404", description = "User role not found")
    })
    public ResponseEntity<ApiResponseHandler> removeRoleFromUser(@PathVariable String userId,
                                                                 @PathVariable UUID roleId) {
        userRoleService.removeUserRole(userId, roleId);
        return ResponseEntity.ok(new ApiResponseHandler(true, "Role removed successfully"));
    }

    @GetMapping("/{userId}/roles")
    @Operation(summary = "Get user roles", description = "Retrieves all roles assigned to a user.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User roles retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<ApiResponseHandler> getUserRoles(@PathVariable String userId) {
        List<RoleRequest> roles = userRoleService.getUserRoles(userId);
        return ResponseEntity.ok(new ApiResponseHandler(true, "User roles retrieved successfully", roles));
    }

    @GetMapping("/{userId}/roles/{roleName}/check")
    @Operation(summary = "Check user role", description = "Checks if a user has a specific role.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Role check completed successfully"),
            @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<ApiResponseHandler> checkUserHasRole(@PathVariable String userId,
                                                               @PathVariable String roleName) {
        boolean hasRole = userRoleService.checkUserRole(userId, roleName);
        Map<String, Boolean> response = Collections.singletonMap("hasRole", hasRole);
        return ResponseEntity.ok(new ApiResponseHandler(true, "Role check completed successfully", response));
    }

    @PostMapping("/{userId}/default-roles")
    @Operation(summary = "Assign default roles", description = "Assigns default roles to a user.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Default roles assigned successfully"),
            @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<ApiResponseHandler> assignDefaultRolesToUser(@PathVariable String userId) {
        userRoleService.assignDefaultRoles(userId);
        return ResponseEntity.ok(new ApiResponseHandler(true, "Default roles assigned successfully"));
    }

    @GetMapping("/my-menu-items")
    @Operation(summary = "Get user permissions", description = "Retrieves a user's roles, permissions, and menu items.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved user menu items with permissions"),
            @ApiResponse(responseCode = "400", description = "Invalid input parameters"),
            @ApiResponse(responseCode = "404", description = "User or project not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<ApiResponseHandler> getUserRolePermissions(@RequestParam(required = false) UUID projectId) {
        UserMenuItemPermissionResponse response = userRoleService.getUserRolesWithPermissions(projectId);
        return ResponseEntity.ok(new ApiResponseHandler(true, "User's roles, permissions, and menu items retrieved successfully", response));
    }

    @GetMapping("project-users")
    @Operation(summary = "Get project users", description = "Retrieves all users and their roles for a given project.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project users retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "Project not found")
    })
    public ApiResponseHandler<Map<String, List<Map<String, Object>>>> getProjectUsers(@RequestParam(required = false) UUID projectId) {
        Map<String, List<Map<String, Object>>> users = userRoleService.getRoleOfUserInProject(projectId);
        return new ApiResponseHandler<>(true, "Project retrieved successfully", users);
    }

    @GetMapping("/{userId}")
    @Operation(summary = "Get Project IDs by User", description = "Fetches project IDs for a given user.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project IDs retrieved successfully")
    })
    public ResponseEntity<Object> getProjectIdsByUser(@PathVariable String userId) {
        List projectIds = userRoleService.getProjectIdsByUser(userId);
        return ResponseEntity.ok(new ApiResponseHandler(true, "Project IDs retrieved successfully", projectIds));
    }

    @DeleteMapping("/delete-project")
    @Operation(summary = "Delete Project", description = "Deletes a project.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Project deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Project not found")
    })
    public ResponseEntity<ApiResponseHandler> deleteProject(@RequestParam UUID projectId, @AuthenticationPrincipal Jwt jwt) {
        userRoleService.removeProject(projectId, jwt);
        return ResponseEntity.ok(new ApiResponseHandler(true, "Project deleted successfully"));
    }

    @PutMapping("/{userId}/projects/{projectId}/roles/{roleId}")
    public ResponseEntity<ApiResponseHandler>updateUserRole(@PathVariable String userId ,@PathVariable UUID projectId,@PathVariable UUID roleId){
       userRoleService.updateUserRole(userId,projectId,roleId);
        return ResponseEntity.ok(new ApiResponseHandler(true,"user roles updated successfully"));
    }

    @PutMapping("/{projectId}/remove-user/{userId}")
    public ResponseEntity<ApiResponseHandler> updateUserRoleAsActiveFalse(@PathVariable UUID projectId,@PathVariable String userId){
        userRoleService.updateUserRoleAsActiveFalse(userId, projectId);
        return ResponseEntity.ok(new ApiResponseHandler(true,"user roles updated successfully"));
    }

    @GetMapping("/{userId}/roles/check")
    @Operation(summary = "Check user and get roles", description = "Checks user and get roles")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User roles retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload")
    })
    public ResponseEntity<ApiResponseHandler<Map<String,Object>>> getRolesByValidUser(@PathVariable String userId) {
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User roles retrieved successfully", userRoleService.getRolesByValidUser(userId)));
    }
}