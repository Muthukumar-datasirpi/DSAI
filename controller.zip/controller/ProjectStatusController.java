package com.example.managementservice.controller;

import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.model.ProjectStatus;
import com.example.managementservice.service.impl.ProjectStatusServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/projects-status")
@Tag(name = "Project Status Controller", description = "Controller for managing project statuses")
public class ProjectStatusController {

    private final ProjectStatusServiceImpl projectStatusService;

    @GetMapping
    @Operation(summary = "Get all project statuses", description = "Retrieves a list of all project statuses.")
    public ResponseEntity<ApiResponseHandler<List<ProjectStatus>>> getAllProjectStatuses() {
        List<ProjectStatus> projectStatuses = projectStatusService.getAllProjectStatuses();
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project statuses fetched successfully", projectStatuses));
    }
}