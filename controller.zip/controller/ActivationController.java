package com.example.managementservice.controller;

import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.service.TenantService;
import com.example.managementservice.utils.AppConstants;
import com.example.managementservice.utils.TokenUtil;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/api/v1/activation")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Activation Controller", description = "Controller for managing tenant activation")
public class ActivationController {

    private final TenantService tenantService;

    private final TokenUtil tokenUtil;

    @PostMapping(value = "/tenants/activate")
    public ResponseEntity<ApiResponseHandler> createTenant(@RequestHeader(AppConstants.X_TENANT_ID_HEADER) String subdomain) {
        try {
            String clientId = tokenUtil.getClientIdFromToken();
            boolean isCreated = tenantService.createTenant(subdomain, clientId);

            if (isCreated) {
                String userId = tokenUtil.getAppUserId();
                log.info("User ID: {}", userId);
                tenantService.userRoleMapping(userId);
                log.info("User role mapping completed for user ID: {}", userId);
                return ResponseEntity.ok(new ApiResponseHandler(true, "Tenant created successfully"));
            } else {
                return ResponseEntity.badRequest().body(new ApiResponseHandler(false, "Tenant creation failed", null));
            }

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(new ApiResponseHandler(false, e.getMessage(), null));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseHandler(false, "An error occurred while creating the tenant", null));
        }
    }


    @GetMapping(value = "/check-tenant")
    public ResponseEntity<ApiResponseHandler> checkTenant(@RequestParam String subdomain) {
        boolean isActive = tenantService.checkTenant(subdomain);
        if (!isActive) {
            return ResponseEntity.badRequest().body(new ApiResponseHandler(false, "Tenant is not active", null));
        }
        return ResponseEntity.ok(new ApiResponseHandler(true, "Tenant is active", null));
    }
}