package com.example.managementservice.controller;

import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.FormConfigResponse;
import com.example.managementservice.model.FormCategory;
import com.example.managementservice.service.impl.FormCategoryServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/form-categories")
@RequiredArgsConstructor
@Tag(name = "Form category controller", description = "Controller for managing form categories")
public class FormCategoryController {

    private final FormCategoryServiceImpl formCategoryService;

    @GetMapping
    @Operation(summary = "Get all form categories", description = "Retrieves a list of all form categories.")
    public ResponseEntity<ApiResponseHandler<List<FormCategory>>> getAllFormCategories() {
        List<FormCategory> formCategories = formCategoryService.getAllFormCategories();
        ApiResponseHandler<List<FormCategory>> response = new ApiResponseHandler<>(true, "Form categories retrieved successfully", formCategories);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/request-type")
    @Operation(summary = "Get request types", description = "Retrieves a list of request types, optionally filtered by category ID.")
    public ResponseEntity<ApiResponseHandler<List<FormConfigResponse>>> getRequestTypes(@RequestParam(required = false) String categoryId) {
        List<FormConfigResponse> formConfigs = formCategoryService.getRequestTypes(categoryId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Method not implemented", formConfigs));
    }
}