package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.PasswordRequest;
import com.example.managementservice.exchange.request.PasswordUpdateRequest;
import com.example.managementservice.exchange.request.UserUpdateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.PaginatedResponse;
import com.example.managementservice.exchange.response.UserProjectRolePermissionResponse;
import com.example.managementservice.exchange.response.UserResponse;
import com.example.managementservice.model.UserRole;
import com.example.managementservice.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
@Tag(name = "User  Controller", description = "APIs for managing user flow")
public class UserController {

    private final UserService userService;

    //TODO fix this api using feign ... Auth service
    @Operation(summary = "Update a user",
            description = "Updates a user's details based on the provided request body.",
            responses = {
                    @ApiResponse(responseCode = "200", description = " User  updated successfully",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiResponseHandler.class))),
                    @ApiResponse(responseCode = "404", description = "User  not found",
                            content = @Content(mediaType = "application/json")),
                    @ApiResponse(responseCode = "400", description = "Invalid input",
                            content = @Content(mediaType = "application/json"))
            })
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponseHandler<Object>> updateUser(
            @Parameter(description = "UUID of the user to be updated") @PathVariable String id,
            @RequestBody @Valid UserUpdateRequest request) {
        userService.updateUser(id, request);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User  updated successfully"));
    }

    @Operation(summary = "Get user by ID",
            description = "Retrieves a user's details based on their UUID.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "User  found",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiResponseHandler.class))),
                    @ApiResponse(responseCode = "404", description = "User  not found",
                            content = @Content(mediaType = "application/json"))
            })
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponseHandler<UserRole>> getUserById(
            @Parameter(description = "UUID of the user") @PathVariable String id) {
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User fetched Successfully", userService.getUserById(id)));
    }

    @Operation(summary = "Get users by IDs",
            description = "Retrieves a list of users based on their UUIDs.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Users found",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiResponseHandler.class))),
                    @ApiResponse(responseCode = "404", description = "Users not found",
                            content = @Content(mediaType = "application/json"))
            })
    @GetMapping("/by-ids")
    public ResponseEntity<ApiResponseHandler<List<UserRole>>> getUsersByIds(@RequestParam List<String> userIds) {
        List<UserRole> users = userService.getUsersByIds(userIds);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Users fetched Successfully", users));
    }

    //TODO fix this api using feign ... Auth service
    @Operation(summary = "Enable a user",
            description = "Enables a user account.",
            responses = {
                    @ApiResponse(responseCode = "204", description = "User  enabled successfully"),
                    @ApiResponse(responseCode = "404", description = "User  not found",
                            content = @Content(mediaType = "application/json"))
            })
    @PostMapping("/{id}/enable")
    public ResponseEntity<ApiResponseHandler<Object>> enableUser(
            @Parameter(description = "UUID of the user to enable") @PathVariable String id) {
        userService.enableUser(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User enabled successfully"));
    }

    @Operation(summary = "Disable a user",
            description = "Disables a user account.",
            responses = {
                    @ApiResponse(responseCode = "204", description = "User  disabled successfully"),
                    @ApiResponse(responseCode = "404", description = "User  not found",
                            content = @Content(mediaType = "application/json"))
            })
    @PostMapping("/{id}/disable")
    public ResponseEntity<ApiResponseHandler<Object>> disableUser(
            @Parameter(description = "UUID of the user to disable") @PathVariable String id) {
        userService.disableUser(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User disabled successfully"));
    }

    @GetMapping("/users")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<UserResponse>>> getAllActiveUsers(
            @Parameter(description = "Page number (0-based)", example = "0")
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Number of records per page", example = "50")
            @RequestParam(defaultValue = "50") int size,
            @Parameter(description = "Field to sort by", example = "createdAt")
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @Parameter(description = "Sort direction ('asc' or 'desc')", example = "asc", schema = @Schema(allowableValues = {"asc", "desc"}))
            @RequestParam(defaultValue = "asc") String direction) {

        PaginatedResponse<UserResponse> usersList = userService.getAllActiveUsers(page,size, sortBy, direction);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Users retrieved successfully", usersList));
    }

    @Operation(summary = "Search for users",
            description = "Search for users based on their username, email, first name, or last name."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Users found",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = ApiResponseHandler.class))),
            @ApiResponse(responseCode = "404", description = "Users not found",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping("/users-search")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<UserResponse>>> searchUsers(
            @Parameter(description = "Page number (0-based)", example = "0")
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Number of records per page", example = "50")
            @RequestParam(defaultValue = "50") int size,
            @Parameter(description = "Field to sort by", example = "createdAt")
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @Parameter(description = "Sort direction ('asc' or 'desc')", example = "asc", schema = @Schema(allowableValues = {"asc", "desc"}))
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) String search) {

        PaginatedResponse<UserResponse> users = userService.searchUsers(search, page, size, sortBy, direction);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Users retrieved successfully", users));
    }

    @GetMapping("/users/all")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<UserResponse>>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) String search) {

        PaginatedResponse<UserResponse> users = userService.getAllUsers(search, page, size, sortBy, direction);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Users retrieved successfully", users));
    }

    @Operation(summary = "Reset user password as an admin", description = "Resets the password of a user as an admin.")
    @PutMapping("/admin/users/{userId}/reset-password")
    public ResponseEntity<ApiResponseHandler<Object>> resetPasswordAdmin(@PathVariable String userId,
                                                                 @RequestParam String newPassword) {
        userService.resetPasswordAdmin(userId, newPassword);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User password reset successful", null));
    }

    @Operation(summary = "Forgot password", description = "Sends a password reset link to the user's email.")
    @PostMapping("/user/forgot-password")
    public ResponseEntity<ApiResponseHandler<Object>> forgotPassword(@RequestParam String email) {
        userService.forgotPassword(email);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Password reset link sent to email", null));
    }

    @Operation(summary = "Reset user password", description = "Resets the password of the user.")
    @PutMapping("/users/reset-password")
    public ResponseEntity<ApiResponseHandler<Object>> resetPasswordUser(@RequestBody PasswordUpdateRequest updateRequest){
        userService.resetPasswordUser(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Password successfully reset", null));
    }

    @Operation(summary = "Update user password", description = "Updates the password of the user.")
    @PutMapping("/users/update/password")
    public ResponseEntity<ApiResponseHandler<Object>> updateUserPassword(@RequestParam String userId, @RequestBody PasswordRequest passwordRequest){
        userService.updateUserPassword(userId, passwordRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Password successfully updated", null));
    }

    @Operation(summary = "fetch user roles and permission", description = "fetch the user of roles and permissions.")
    @GetMapping("/users/roles")
    public ResponseEntity<ApiResponseHandler<Object>>fetchUsersRolePermission(){
        List<UserProjectRolePermissionResponse> users=userService.fetchUsersRolePermission();
        return ResponseEntity.ok(new ApiResponseHandler<>(true,"Fetch user roles Permission",users));
    }
}