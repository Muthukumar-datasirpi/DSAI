package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.RequestTypeCreateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.RequestTypeResponse;
import com.example.managementservice.service.impl.RequestTypeServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/request-types")
@RequiredArgsConstructor
@Tag(name = "Request Type Controller", description = "Controller for managing request types")
public class RequestTypeController {

    private final RequestTypeServiceImpl requestTypeService;

    @PostMapping
    @Operation(summary = "Create a new request type", description = "Creates a new request type with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createRequestType(@RequestBody RequestTypeCreateRequest createRequest) {
        requestTypeService.createRequestType(createRequest);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponseHandler<>(true, "Request type created successfully", null));
    }

    @GetMapping
    @Operation(summary = "Get all request types", description = "Retrieves a list of all request types.")
    public ResponseEntity<ApiResponseHandler<List<RequestTypeResponse>>> getAllRequestTypes() {
        List<RequestTypeResponse> requestTypes = requestTypeService.getAllRequestTypes();
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Request types retrieved successfully", requestTypes));
    }
}