package com.example.managementservice.controller;

import com.example.managementservice.config.multitenant.UserChecker;
import com.example.managementservice.config.ActivityLogger;
import com.example.managementservice.exchange.request.CreateTimeEntryRequest;
import com.example.managementservice.exchange.request.TimeEntryCreateRequest;
import com.example.managementservice.exchange.request.TimeEntryUpdateRequest;
import com.example.managementservice.exchange.response.*;
import com.example.managementservice.model.TimeEntry;
import com.example.managementservice.repository.TimeEntryRepository;
import com.example.managementservice.service.impl.TimeEntryServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/time-tracker")
@RequiredArgsConstructor
@Tag(name = "Time Tracker Controller", description = "APIs for managing time tracking and entries")
public class TimeTrackerController {

    private final TimeEntryServiceImpl timeEntryService;
    private final ActivityLogger activityLogger;
    private final TimeEntryRepository timeEntryRepository;
    private final UserChecker userChecker;

    @PreAuthorize("@userChecker.canModifyProject(#createRequest.projectId)")
    @PostMapping
    @Operation(summary = "Create a new time entry", description = "Creates a new time entry for a user.")
    public ResponseEntity<ApiResponseHandler<Object>> createTimeEntry(@Valid @RequestBody TimeEntryCreateRequest createRequest, @AuthenticationPrincipal Jwt jwt){
        timeEntryService.createTimeEntry(createRequest);
        String entityName = createRequest.getClass().getSimpleName().replaceAll("(Request|DTO|Response)$", "");
        activityLogger.logActivity(null, createRequest, jwt, entityName);
        return ResponseEntity.ok(new ApiResponseHandler<>(true,"Time entry has been created successfully"));
    }

    @PostMapping("/user/time-sheet")
    @Operation(summary = "Create issue and time entry", description = "Creates a new issue and associated time entries for a user.")
    public ResponseEntity<ApiResponseHandler<Object>> createIssueAndTimeEntry(@Valid @RequestBody List<CreateTimeEntryRequest>  createRequestList, @AuthenticationPrincipal Jwt jwt){
        timeEntryService.createIssueAndTimeEntry(createRequestList, jwt);
        return ResponseEntity.ok(new ApiResponseHandler<>(true,"Time entry's has been created successfully"));
    }

    @GetMapping("/{issueId}")
    @Operation(summary = "Get all time entries for an issue", description = "Retrieves all time entries associated with a specific issue.")
    public ResponseEntity<ApiResponseHandler<TimeEntryIssueResponse>> getAllTimeEntriesForIssue(@PathVariable UUID issueId) {
        TimeEntryIssueResponse timeEntries = timeEntryService.getAllTimeEntriesForIssue(issueId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entries retrieved successfully", timeEntries));
    }

    @GetMapping("/user/time-sheet")
    @Operation(summary = "Get all time entries for a user", description = "Retrieves all time entries for a specific user within an optional date range.")
    public ResponseEntity<ApiResponseHandler<Object>> getAllTimeEntriesForUser(@RequestParam String userId,
                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate) {
        List<TimeTrackerResponse> response = timeEntryService.getAllTimeEntriesForUser(userId, fromDate, toDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entries retrieved successfully", response));
    }

    @PatchMapping("/user/time-sheet")
    public ResponseEntity<ApiResponseHandler<Object>> updateUserTimeEntry(@AuthenticationPrincipal Jwt jwt, @RequestBody List<CreateTimeEntryRequest>  createRequest) {
        timeEntryService.updateUserTimeEntry(createRequest, jwt);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entry's has been updated successfully"));
    }

    @PostMapping("/user/time-sheet-v1")
    @Operation(summary = "Store user time entry tracker", description = "Stores multiple time entries for a user in a single request.")
    public ResponseEntity<ApiResponseHandler<Object>> storeUserTimeEntryTracker(@RequestBody List<CreateTimeEntryRequest>  createRequest, @AuthenticationPrincipal Jwt jwt) {
        timeEntryService.storeUserTimeEntryTracker(createRequest, jwt);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entry's has been stored successfully"));
    }

    @PutMapping
    @Operation(summary = "Update a time entry", description = "Updates an existing time entry based on the provided ID and details.")
    public ResponseEntity<ApiResponseHandler<Object>> updateTimeEntry(@RequestBody TimeEntryUpdateRequest updateRequest) {
        TimeEntry existing = timeEntryRepository.findById(updateRequest.getId())
                .orElseThrow(() -> new NotFoundException("Time entry not found"));
        String projectId = existing.getIssue().getProjectId().getProjectId().toString();
        if (!userChecker.canModifyProject(UUID.fromString(projectId))) {
            throw new AccessDeniedException("Action not allowed: the selected project is already marked as Completed.");
        }
        timeEntryService.updateTimeEntry(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entry has been updated successfully"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a time entry", description = "Deletes a specific time entry by its ID.")
    public ResponseEntity<ApiResponseHandler<Object>> deleteTimeEntry(@PathVariable String id) {
        TimeEntry timeEntry = timeEntryRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Time entry not found"));
        UUID projectId = timeEntry.getIssue().getProjectId().getProjectId();
        if (!userChecker.canModifyProject(projectId)) {
            throw new AccessDeniedException("Action not allowed: the selected project is already marked as Completed.");
        }
        timeEntryService.deleteTimeEntry(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entry has been deleted successfully"));
    }

    @DeleteMapping("/user/time-sheet")
    @Operation(summary = "Delete time entries for a user", description = "Deletes multiple time entries for a user based on their IDs.")
    public ResponseEntity<ApiResponseHandler<Object>> deleteTimeEntry(@RequestParam List<String> timeEntryIds) {
        timeEntryService.deleteTimeEntry(timeEntryIds);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entry's has been deleted successfully"));
    }

    @GetMapping("/project/{projectId}")
    @Operation(summary = "Get time entries for users in a project", description = "Retrieves all time entries for users in a specific project.")
    public ResponseEntity<ApiResponseHandler<TimeTrackerDetails>> getTimeEntryForUsersInProject(@PathVariable UUID projectId, @RequestParam(required = false) LocalDate startDate, @RequestParam(required = false) LocalDate endDate) {
        TimeTrackerDetails timeEntries = timeEntryService.getTimeEntryForUsersInProject(projectId, startDate, endDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entries for users in project retrieved successfully", timeEntries));
    }

    @GetMapping("/projects")
    @Operation(summary = "Get time entries for users in multiple projects", description = "Retrieves all time entries for users in a list of projects.")
    public ResponseEntity<ApiResponseHandler<Map<String,TimeTrackerDetails>>> getTimeEntryForUsersInListProject(@RequestParam List<UUID> projectIds, @RequestParam(required = false) LocalDate startDate, @RequestParam(required = false) LocalDate endDate) {
        Map<String, TimeTrackerDetails> timeEntries = timeEntryService.getTimeEntryForUsersInListProject(projectIds, startDate, endDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entries for users in project retrieved successfully", timeEntries));
    }

    @GetMapping("/user/{userId}/project/{projectId}")
    @Operation(summary = "Get time entries for a user in a specific project", description = "Retrieves all time entries for a specific user in a given project.")
    public ResponseEntity<ApiResponseHandler<UserTimeEntryResponse>> getTimeEntriesForUser(@PathVariable String userId, @PathVariable UUID projectId,  @RequestParam(required = false) LocalDate startDate, @RequestParam(required = false) LocalDate endDate) {
        UserTimeEntryResponse timeEntries = timeEntryService.getTimeEntriesForUser(userId, projectId, startDate, endDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entries for user retrieved successfully", timeEntries));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get time entries for a user in all projects", description = "Retrieves all time entries for a specific user across all projects.")
    public ResponseEntity<ApiResponseHandler<UserTimeEntryResponse>> getTimeEntriesForUserInAllProjects(@PathVariable String userId,  @RequestParam(required = false) LocalDate startDate, @RequestParam(required = false) LocalDate endDate) {
        UserTimeEntryResponse timeEntries = timeEntryService.getTimeEntriesForUserInAll(userId, startDate, endDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Time entries for user in all project retrieved successfully", timeEntries));
    }

    @PreAuthorize("@userChecker.canModifyProject(#projectId)")
    @PostMapping("/download/excel")
    @Operation(summary = "Download time entries as Excel", description = "Downloads time entries for a project or user in Excel format.")
    public ResponseEntity<byte[]> downloadTimeEntriesExcel(@RequestParam UUID projectId, @RequestParam(required = false) String userId, @RequestParam(required = false) LocalDate startDate, @RequestParam(required = false) LocalDate endDate) {
        byte[] excelFile;
        if (userId != null && !userId.isBlank()) {
            UserTimeEntryResponse userTimeEntry = timeEntryService.getTimeEntriesForUser(userId, projectId, startDate, endDate);
            excelFile = timeEntryService.downloadUserTimeEntryExcel(userTimeEntry);
        } else {
            TimeTrackerDetails projectTimeEntries = timeEntryService.getTimeEntryForUsersInProject(projectId, startDate, endDate);
            excelFile = timeEntryService.downloadTimeEntriesExcel(projectTimeEntries);
        }
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Time-Tracker-Report.xlsx")
                .body(excelFile);
    }
}