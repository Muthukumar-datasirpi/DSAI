package com.example.managementservice.controller;

import com.example.managementservice.exception.BusinessException;
import com.example.managementservice.exchange.request.RegisterRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.service.InvitationService;
import com.example.managementservice.service.UserService;
import com.example.managementservice.utils.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;
import java.util.concurrent.CompletionException;

@RestController
@RequestMapping("/api/v1/invite")
@RequiredArgsConstructor
@Tag(name = "User Invite Controller", description = "APIs for managing authentication and user flow")
public class UserInviteController {
    private final InvitationService invitationService;
    private final UserService userService;

    @Operation(summary = "Invite a user to a project",
            description = "Sends an invitation email to a user for a specific project and role.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Invitation sent successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @PostMapping("/invite")
    public ResponseEntity<ApiResponseHandler> inviteUser(
            @RequestParam String email,
            @AuthenticationPrincipal Jwt jwt,
            @RequestParam(required = false) UUID projectId,
            @RequestParam UUID roleId) {

        try {
            invitationService.inviteUserToProject(email, projectId, roleId, jwt);
            return ResponseEntity.ok(new ApiResponseHandler(true, "User invited successfully"));
        } catch (CompletionException e) {
            Throwable cause = e.getCause();
            if (cause instanceof BusinessException) {
                return ResponseEntity.badRequest()
                        .body(new ApiResponseHandler(false, cause.getMessage()));
            } else {
                return ResponseEntity.internalServerError().body(new ApiResponseHandler(false, "Failed to invite user"));
            }
        }
    }

    @Operation(summary = "Register a new user",
            description = "Registers a user using an invitation token, full name, and password.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "User registered successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid token or request body", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = @Content)
    })
    @PostMapping("/register")
    public ResponseEntity<ApiResponseHandler> registerUser(@RequestHeader(AppConstants.X_TENANT_ID_HEADER) String subdomain, @Valid @RequestBody RegisterRequest registerRequest, @AuthenticationPrincipal Jwt jwt) {
        try {
            userService.registerUser(subdomain,jwt, registerRequest);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User created successfully"));
    }
}