package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.PermissionRequest;
import com.example.managementservice.exchange.request.PermissionRequestV2;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.service.PermissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/permissions")
@Tag(name = "Permissions", description = "APIs for managing permissions in the system")
@RequiredArgsConstructor
public class PermissionController {

    private final PermissionService permissionService;

    @Operation(summary = "Create a new permission", description = "Creates a new permission and returns the created permission details.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Permission created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload")
    })
    @PostMapping
    public ResponseEntity<PermissionRequestV2> createPermissionV2(@RequestBody PermissionRequestV2 permissionRequest) {
        PermissionRequestV2 createdPermission = permissionService.createPermissionV2(permissionRequest);
        return ResponseEntity.status(201).body(createdPermission);
    }

    @Operation(summary = "Get permission by ID", description = "Fetches a permission by its unique identifier.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Permission found"),
            @ApiResponse(responseCode = "404", description = "Permission not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<PermissionRequest> getPermissionById(@PathVariable UUID id) {
        return permissionService.getPermissionById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get permission by code", description = "Fetches a permission by its unique permission code.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Permission found"),
            @ApiResponse(responseCode = "404", description = "Permission not found")
    })
    @GetMapping("/code/{permissionCode}")
    public ResponseEntity<PermissionRequest> getPermissionByCode(@PathVariable String permissionCode) {
        return permissionService.getPermissionByCode(permissionCode)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get all permissions", description = "Fetches a list of all available permissions.")
    @ApiResponse(responseCode = "200", description = "List of permissions retrieved successfully")
    @GetMapping
    public ResponseEntity<ApiResponseHandler<List<PermissionRequest>>> getAllPermissions() {
        List<PermissionRequest> permissions = permissionService.getAllPermissions();
            return ResponseEntity.ok(new ApiResponseHandler<>(true, "permission retrieved successfully", permissions));

    }

    @Operation(summary = "Update a permission", description = "Updates an existing permission and returns the updated details.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Permission updated successfully"),
            @ApiResponse(responseCode = "404", description = "Permission not found")
    })
    @PutMapping("/{id}")
    public ResponseEntity<PermissionRequestV2> updatePermission(@PathVariable UUID id, @RequestBody PermissionRequestV2 permissionRequest) {
        PermissionRequestV2 updatedPermission = permissionService.updatePermission(id, permissionRequest);
        return ResponseEntity.ok(updatedPermission);
    }

    @Operation(summary = "Delete a permission", description = "Deletes a permission by its ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Permission deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Permission not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePermission(@PathVariable UUID id) {
        permissionService.deletePermission(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Get permissions by role ID", description = "Fetches a list of permissions assigned to a specific role.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Permissions retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "Role not found or has no permissions")
    })
    @GetMapping("/permissions/{roleId}")
    public ResponseEntity<List<PermissionRequest>> getPermissionsByRoleId(@PathVariable UUID roleId) {
        List<PermissionRequest> permissions = permissionService.getPermissionsByRoleId(roleId);
        return ResponseEntity.ok(permissions);
    }
}