package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.SlaPolicyRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.SlaPolicyResponse;
import com.example.managementservice.service.impl.SlaPolicyServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sla-policies")
@RequiredArgsConstructor
@Tag(name = "SLA Policy Controller", description = "Controller for managing SLA policies")
public class SlaPolicyController {

    private final SlaPolicyServiceImpl slaPolicyService;

    @PostMapping
    @Operation(summary = "Create SLA Policy", description = "Creates a new SLA policy with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createPolicy(@RequestBody SlaPolicyRequest request) {
        slaPolicyService.createPolicy(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponseHandler<>(true, "SLA policy created successfully"));
    }

    @GetMapping
    @Operation(summary = "Get all SLA Policies", description = "Fetches all SLA policies")
    public ResponseEntity<ApiResponseHandler<List<SlaPolicyResponse>>> getPolicies() {
        List<SlaPolicyResponse> slaPolicies = slaPolicyService.getAllPolicies();
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Policies fetched successfully", slaPolicies));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get SLA Policy by ID", description = "Fetches an SLA policy by its ID")
    public ResponseEntity<ApiResponseHandler<SlaPolicyResponse>> getPolicy(@PathVariable String id) {
        SlaPolicyResponse slaPolicy = slaPolicyService.getPolicy(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Policy fetched successfully", slaPolicy));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete SLA Policy", description = "Deletes an SLA policy by its ID")
    public ResponseEntity<ApiResponseHandler<Object>> deletePolicy(@PathVariable String policyId) {
        slaPolicyService.deletePolicy(policyId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Policy deleted successfully"));
    }
}