package com.example.managementservice.controller;

import com.example.managementservice.exchange.response.AdminUserDashboardResponse;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.service.GraphService;
import com.example.managementservice.utils.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/graph")
@RequiredArgsConstructor
@Tag(name = "Graph Management controller", description = "APIs for managing graphs and reports")
public class GraphController {

    private final GraphService graphService;

    @GetMapping("/issue-graph")
    @Operation(summary = "Get all issues with their projects", description = "Fetches all issues along with their associated projects.")
    public ResponseEntity<ApiResponseHandler<Object>> allIssues(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @RequestParam(required = false) UUID projectId) {
        return ResponseEntity.ok(
                new ApiResponseHandler<>(true, "Issues fetched successfully",
                        graphService.getAllProjectsWithIssues(projectId))
        );
    }

    @GetMapping("/project-progress")
    @Operation(summary = "Get project progress and task report", description = "Fetches the progress of a project along with its task report.")
    public ResponseEntity<ApiResponseHandler<Object>> getProjectProgressAndTaskReport(
            @AuthenticationPrincipal Jwt jwt, @RequestParam() UUID projectId){

        Map<String, Object> response = graphService.getProjectProgressAndTaskReport(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project progress retrieved successfully", response));
    }

    @GetMapping("/project/week-progress")
    @Operation(summary = "Get weekly project progress by project ID", description = "Fetches the weekly progress of a project based on the provided project ID.")
    public ResponseEntity<ApiResponseHandler<Object>> getWeeklyProjectProgressByProjectId(
            @AuthenticationPrincipal Jwt jwt, @RequestParam() UUID projectId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate){

        Map<String, Object> response = graphService.getProjectProgressByProjectId(projectId, fromDate, toDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Weekly project data retrieved successfully", response));
    }

    @GetMapping("/user-progress")
    @Operation(summary = "Get user progress", description = "Fetches the progress of a user based on the provided user ID and optional date range.")
    public ResponseEntity<ApiResponseHandler<Object>> getUserProgress(
            @AuthenticationPrincipal Jwt jwt, @RequestParam() String userId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate){

        Map<String, Object> response = graphService.getUserProgress(userId, fromDate, toDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User progress data retrieved successfully", response));
    }

    @GetMapping("/user-activity")
    @Operation(summary = "Get user activity", description = "Fetches the activity of a user based on the provided user ID and pagination parameters.")
    public ResponseEntity<ApiResponseHandler<Object>> getUserActivity(
            @AuthenticationPrincipal Jwt jwt, @RequestParam() String userId,
            @RequestParam(defaultValue = "1") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize){

        Map<String, Object> response = graphService.getUserActivity(userId, pageNo-1, pageSize);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User activity data retrieved successfully", response));
    }

    @GetMapping("/admin/task-progress")
    @Operation(summary = "Get admin task progress", description = "Fetches the progress of admin tasks.")
    public ResponseEntity<ApiResponseHandler<Object>> getAdminTaskProgress(
            @AuthenticationPrincipal Jwt jwt){

        Map<String, Object> response = graphService.getAdminTaskProgress();
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Admin project progress data retrieved successfully", response));
    }

    @GetMapping("/admin/week-progress")
    @Operation(summary = "Get admin weekly project progress", description = "Fetches the weekly progress of admin projects.")
    public ResponseEntity<ApiResponseHandler<Object>> getWeekAdminTaskProgress(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate){

        Map<String, Object> response = graphService.getAdminProjectProgress(fromDate, toDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Admin week project progress retrieved successfully", response));
    }

    @GetMapping("/admin/project/time-tracker")
    @Operation(summary = "Get active project time log", description = "Fetches the time log of active projects.")
    public ResponseEntity<ApiResponseHandler<Object>> getActiveProjectTimeLog(
            @RequestParam(required = false) LocalDate startDate, @RequestParam(required = false) LocalDate endDate,
            @AuthenticationPrincipal Jwt jwt){

        Map<String, Object> response = graphService.getActiveProjectTimeLog(startDate, endDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Admin active project time entry data retrieved successfully", response));
    }

    @GetMapping("/user")
    @Operation(summary = "Get user dashboard", description = "Fetches the dashboard data for a specific user based on their ID and optional date range.")
    public ResponseEntity<ApiResponseHandler<AdminUserDashboardResponse>> getUserDashboard(
            @RequestParam String userId,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate) {
        AdminUserDashboardResponse response = graphService.getUserDashboard(userId, startDate, endDate);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "User dashboard fetched successfully", response));
    }
}