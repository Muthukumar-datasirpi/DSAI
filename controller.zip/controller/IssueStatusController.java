package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.IssueStatusCreateRequest;
import com.example.managementservice.exchange.request.IssueStatusSortOrderRequest;
import com.example.managementservice.exchange.request.IssueStatusUpdateRequest;
import com.example.managementservice.exchange.request.enums.StatusCategory;
import com.example.managementservice.exchange.response.*;
import com.example.managementservice.service.impl.IssueStatusServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/issue-status")
@Tag(name = "Issue Status Controller", description = "Controller for managing issue statuses")
public class IssueStatusController {

    private final IssueStatusServiceImpl issueStatusService;

    @PostMapping
    @Operation(summary = "Create a new issue status", description = "Creates a new issue status with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createIssueStatus(@Valid @RequestBody IssueStatusCreateRequest createRequest){
        issueStatusService.createIssueStatus(createRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Issue status created successfully", null));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get issue status by ID", description = "Fetches a specific issue status by its ID.")
    public ResponseEntity<ApiResponseHandler<IssueStatusDetails>> getIssueStatusById(@PathVariable String id) {
        IssueStatusDetails projectStatus = issueStatusService.getIssueStatusById(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Issue status retrieved successfully", projectStatus));
    }

    @GetMapping
    @Operation(summary = "Get all issue statuses for a project", description = "Retrieves all issue statuses associated with a specific project.")
    public ResponseEntity<ApiResponseHandler<ProjectIssueStatus>> getAllIssueStatus(@RequestParam UUID projectId) {
        ProjectIssueStatus issueStatus = issueStatusService.getAllIssueStatus(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "All Issue status for the project has been retrieved successfully", issueStatus));
    }

    @GetMapping("/active")
    @Operation(summary = "Get all active issue statuses for a project", description = "Retrieves all active issue statuses associated with a specific project.")
    public ResponseEntity<ApiResponseHandler<ProjectIssueStatus>> getAllActiveIssueStatus(@RequestParam UUID projectId) {
        ProjectIssueStatus issueStatus = issueStatusService.getAllActiveIssueStatus(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "All active Issue status for the project has been retrieved successfully", issueStatus));
    }

    @PutMapping
    @Operation(summary = "Update an existing issue status", description = "Updates the details of an existing issue status.")
    public ResponseEntity<ApiResponseHandler<Object>> updateIssueStatus(@Valid @RequestBody IssueStatusUpdateRequest updateRequest) {
        issueStatusService.updateIssueStatus(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project status updated successfully", null));
    }

    @DeleteMapping("/{oldStatusId}")
    @Operation(summary = "Delete an issue status", description = "Deletes an existing issue status by its ID, optionally transferring issues to a new status.")
    public ResponseEntity<ApiResponseHandler<Object>> deleteIssueStatus(@PathVariable String oldStatusId, @RequestParam(required = false) String newStatusId) {
        issueStatusService.deleteIssueStatus(oldStatusId, newStatusId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Project status deleted successfully", null));
    }

    @PutMapping("/sort-order")
    @Operation(summary = "Update sort order of issue statuses", description = "Updates the sort order of issue statuses based on the provided request.")
    public ResponseEntity<ApiResponseHandler<Object>> updateSortOrder(@RequestBody IssueStatusSortOrderRequest sortOrderRequest) {
        issueStatusService.updateSortOrder(sortOrderRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sort order updated successfully", null));
    }

    @GetMapping("/status-category")
    @Operation(summary = "Get issues by status category", description = "Retrieves a paginated list of issues filtered by status category, with optional project and user filters.")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<IssueResponse>>> getIssuesByStatusCategory(@RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "100") int size, @RequestParam(required = false) UUID projectId, @RequestParam(required = false) String userId, @RequestParam StatusCategory statusCategory,
                                                                                                          @RequestParam(defaultValue = "createdAt") String sortBy, @RequestParam(defaultValue = "desc") String sortDirection) {
        PaginatedResponse<IssueResponse> issues = issueStatusService.getIssuesByStatusCategory(page, size, projectId, userId,statusCategory, sortBy, sortDirection);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Issues retrieved successfully", issues));
    }

    @PutMapping("/activate/{id}")
    @Operation(summary = "Activate an issue status", description = "Activates an existing issue status by its ID.")
    public ResponseEntity<ApiResponseHandler<Object>> activateIssueStatus(@PathVariable String id) {
        issueStatusService.activateIssueStatus(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Issue status activated successfully", null));
    }
}