package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.TeamCreateRequest;
import com.example.managementservice.exchange.request.TeamUpdateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.PaginatedResponse;
import com.example.managementservice.exchange.response.TeamResponse;
import com.example.managementservice.model.Teams;
import com.example.managementservice.service.impl.TeamServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/teams")
@Tag(name = "Team Controller", description = "Controller for managing teams")
@RequiredArgsConstructor
public class TeamController {

    private final TeamServiceImpl teamService;

    @PostMapping
    @Operation(summary = "Create a new team", description = "Creates a new team with the provided details.")
    public ResponseEntity<ApiResponseHandler<Teams>> createTeam(@Valid @RequestBody TeamCreateRequest teamCreateRequest){
        Teams teams = teamService.createTeam(teamCreateRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseHandler<Teams>(true, "Team created successfully", teams));
    }

    @GetMapping
    @Operation(summary = "Get all teams", description = "Retrieves a paginated list of all teams with optional search and deletion status.")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<TeamResponse>>> getAllTeams(@RequestParam int page, @RequestParam int limit, @RequestParam Boolean isDeleted, @RequestParam(required = false) String search) {
        PaginatedResponse<TeamResponse> teams = teamService.getAllTeams(page, limit, isDeleted, search);
        return ResponseEntity.ok(new ApiResponseHandler<PaginatedResponse<TeamResponse>>(true, "Teams retrieved successfully", teams));
    }

    @GetMapping("/{teamId}")
    @Operation(summary = "Get team by ID", description = "Retrieves a specific team by its ID.")
    public ResponseEntity<ApiResponseHandler<TeamResponse>> getTeamById(@PathVariable String teamId){
        TeamResponse teams = teamService.getTeamById(teamId);
        return ResponseEntity.ok(new ApiResponseHandler<TeamResponse>(true, "Team retrieved successfully", teams));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get teams by user ID", description = "Retrieves a list of teams associated with a specific user ID.")
    public ResponseEntity<ApiResponseHandler<List<TeamResponse>>> getTeamByUserId(@PathVariable String userId){
        List<TeamResponse> teams = teamService.getTeamByUserId(userId);
        return ResponseEntity.ok(new ApiResponseHandler<List<TeamResponse>>(true, "Teams retrieved successfully", teams));
    }

    @PutMapping
    @Operation(summary = "Update an existing team", description = "Updates the details of an existing team.")
    public ResponseEntity<ApiResponseHandler<Teams>> updateTeam(@RequestBody TeamUpdateRequest teams){
        Teams updatedTeam = teamService.updateTeam(teams);
        return ResponseEntity.ok(new ApiResponseHandler<Teams>(true, "Team updated successfully", updatedTeam));
    }

    @DeleteMapping("/{teamId}")
    @Operation(summary = "Delete a team", description = "Deletes a team by its ID.")
    public ResponseEntity<ApiResponseHandler<Object>> deleteTeam(@PathVariable String teamId){
        teamService.deleteTeam(teamId);
        return ResponseEntity.ok(new ApiResponseHandler<Object>(true, "Team deleted successfully", null));
    }

    @DeleteMapping
    @Operation(summary = "Delete a user from a team", description = "Deletes a user from a specific team by team ID and user ID.")
    public ResponseEntity<ApiResponseHandler<Object>> deleteUserFromTeam(@RequestParam String teamId, @RequestParam String userId) {
        teamService.deleteUserFromTeam(teamId, userId);
        return ResponseEntity.ok(new ApiResponseHandler<Object>(true, "User deleted from team successfully", null));
    }

    @GetMapping("/team-ids")
    @Operation(summary = "Get all team IDs", description = "Retrieves a list of all team IDs.")
    public List<String> getAllTeams() {
        return teamService.getAllTeamIds();
    }

    @GetMapping("/{teamId}/user-ids")
    @Operation(summary = "Get user IDs by team ID", description = "Retrieves a list of user IDs associated with a specific team ID.")
    public List<String> getUserIdsByTeamId(@PathVariable String teamId) {
       return teamService.getUserIdsByTeamId(teamId);
    }

    @PostMapping("/users/teams")
    @Operation(summary = "Get teams for multiple user IDs", description = "Retrieves a map of team names for a list of user IDs.")
    public Map<String, List<String>> getTeamsForUserIds(@RequestBody List<String> userIds) {
        return teamService.getTeamsForUserIds(userIds);
    }

    @GetMapping("/teams/all")
    @Operation(summary = "Get all team names", description = "Retrieves a list of all team names.")
    public List<String> getAllTeamName() {
        return teamService.getAllTeamName();
    }

    @PostMapping("/teams/all")
    @Operation(summary = "Get team names for multiple team IDs", description = "Retrieves a list of team names for a list of team IDs.")
    public List<String> getTeamNameForTeamIds(@RequestBody List<String> teamIds) {
        return teamService.getTeamNameForTeamIds(teamIds);
    }
}