package com.example.managementservice.controller;

import com.example.managementservice.config.ActivityLogger;
import com.example.managementservice.exchange.request.ProjectCategoryRequest;
import com.example.managementservice.exchange.request.UpdateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.model.ProjectCategory;
import com.example.managementservice.service.CategoryService;
import com.example.managementservice.utils.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/v1/category")
@Tag(name = "Category Management", description = "APIs for managing categories")
public class CategoryController {

    private final CategoryService categoryService;
    private final ActivityLogger activityLogger;

    @PostMapping(value = "/create")
    @Operation(summary = "Create a new category", description = "Creates a new category with the given details")
    public ResponseEntity<ApiResponseHandler<Object>> createCategory(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @RequestBody @Valid ProjectCategoryRequest projectCategoryRequest,
            @AuthenticationPrincipal Jwt jwt) {
        ProjectCategory projectCategory = categoryService.createCategory(projectCategoryRequest, jwt);        String entityName = projectCategoryRequest.getClass().getSimpleName().replaceAll("(Request|DTO|Response)$", "");
        activityLogger.logActivity(null, projectCategory, jwt, entityName);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponseHandler<>(true, "Category created successfully"));
    }

    @GetMapping
    @Operation(summary = "Get all categories", description = "Retrieves a paginated list of all categories with sorting capabilities")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved the list of categories"),
            @ApiResponse(responseCode = "400", description = "Invalid page, size or sort parameters"),
            @ApiResponse(responseCode = "403", description = "Unauthorized access")
    })
    public ResponseEntity<ApiResponseHandler<Object>> getAllCategories(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @Parameter(description = "Page number (0-based)", example = "0")
            @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Number of records per page", example = "10")
            @RequestParam(defaultValue = "10") int size,
            @Parameter(description = "Field to sort by", example = "createdAt")
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @Parameter(description = "Sort direction ('asc' or 'desc')", example = "asc", schema = @Schema(allowableValues = {"asc", "desc"}))
            @RequestParam(defaultValue = "asc") String direction) {
        Sort.Direction sortDirection = direction.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));
        Object response = categoryService.getAllCategories(pageable);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "List retrieved successfully", response));
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Get category by ID", description = "Retrieves category details by ID")
    public ResponseEntity<ApiResponseHandler<ProjectCategory>> getCategoryById(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @PathVariable UUID id) {
        ProjectCategory category = categoryService.getCategoryById(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Category retrieved successfully", category));
    }

    @PutMapping(value = "/update/{id}")
    @Operation(summary = "Update category", description = "Updates category details by ID")
    public ResponseEntity<ApiResponseHandler<Object>> updateCategory(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @PathVariable UUID id,
            @RequestBody @Valid ProjectCategoryRequest projectCategoryRequest,
            @AuthenticationPrincipal Jwt jwt) {
        UpdateRequest updateRequest = categoryService.updateCategory(id, projectCategoryRequest, jwt);
        String entityName = projectCategoryRequest.getClass().getSimpleName().replaceAll("(Request|DTO|Response)$", "");
        activityLogger.logActivity(updateRequest.getOldValue(), updateRequest.getUpdatedValue(), jwt, entityName);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Category updated successfully"));
    }

    @DeleteMapping(value = "/delete/{id}")
    @Operation(summary = "Delete category", description = "Deletes a category by ID")
    public ResponseEntity<ApiResponseHandler<Object>> deleteCategory(
            @RequestHeader(value = AppConstants.PROJECT_ID_HEADER, required = false) String projectIdHeader,
            @PathVariable UUID id,
            @AuthenticationPrincipal Jwt jwt) {
        ProjectCategory category = categoryService.deleteCategory(id, jwt);
        String entityName = category.getClass().getSimpleName().replaceAll("(Request|DTO|Response)$", "");
        activityLogger.logActivity(category.getTitle(), null, jwt, entityName);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Category deleted successfully"));
    }
}