package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.RolePermissionAssignRequest;
import com.example.managementservice.exchange.request.RoleRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.RolePermissionAssignResponse;
import com.example.managementservice.model.Permission;
import com.example.managementservice.service.RoleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/roles")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Role Management", description = "APIs for managing roles")
public class RoleController {

    private final RoleService roleService;

    @PostMapping
    @Operation(summary = "Create Role", description = "Creates a new role")
    public ResponseEntity<RoleRequest> createRole(@RequestBody RoleRequest roleRequest) {
        RoleRequest createdRole = roleService.createRole(roleRequest);
        return new ResponseEntity<>(createdRole, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get Role by ID", description = "Fetches a role by its ID")
    public ResponseEntity<RoleRequest> getRoleById(@PathVariable UUID id) {
        return roleService.getRoleById(id)
                .map(roleDto -> new ResponseEntity<>(roleDto, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/name/{name}")
    @Operation(summary = "Get Role by Name", description = "Fetches a role by its name")
    public ResponseEntity<RoleRequest> getRoleByName(@PathVariable String name) {
        return roleService.getRoleByName(name)
                .map(roleDto -> new ResponseEntity<>(roleDto, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping
    @Operation(summary = "Get All Roles", description = "Fetches all available roles")
    public ResponseEntity<ApiResponseHandler<List<RoleRequest>>> getAllRoles() {
        List<RoleRequest> roles = roleService.getAllRoles();
        log.info("Roles: {}", roles);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "roles retrieved successfully", roles));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update Role", description = "Updates an existing role")
    public ResponseEntity<RoleRequest> updateRole(@PathVariable UUID id, @RequestBody RoleRequest roleRequest) {
        try {
            RoleRequest updatedRole = roleService.updateRole(id, roleRequest);
            return new ResponseEntity<>(updatedRole, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete Role", description = "Deletes a role by ID")
    public ResponseEntity<Void> deleteRole(@PathVariable UUID id) {
        try {
            roleService.deleteRole(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/assign-permissions")
    @Operation(summary = "Assign Multiple Permissions to Role", description = "Assigns multiple permissions to a role")
    public ResponseEntity<ApiResponseHandler>assignPermissionsToRole(
            @RequestBody List<RolePermissionAssignRequest> requests) {
        roleService.assignPermissionsToRole(requests);
        return ResponseEntity.ok(new ApiResponseHandler<>(true,"assigned permissions roles to permissions",null));
    }

    @GetMapping("/assign-permissions")
    @Operation(summary = "Fetch Multiple Permissions to Role", description = "Fetches multiple permissions to a role")
    public ResponseEntity<ApiResponseHandler> getAllAssignPermissionsRole() {
        List<RolePermissionAssignResponse> roles = roleService.getAllAssignPermissionsRole();
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "assigned  permissions to role retrieved successfully", roles));
    }


    @DeleteMapping("/{roleId}/permissions/{permissionId}")
    @Operation(summary = "Remove Permission from Role", description = "Removes a permission from a role")
    public ResponseEntity<Void> removePermissionFromRole(
            @PathVariable UUID roleId,
            @PathVariable UUID permissionId) {
        try {
            roleService.removePermissionFromRole(roleId, permissionId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{roleId}/permissions")
    @Operation(summary = "Get Permissions by Role ID", description = "Fetches permissions assigned to a specific role")
    public ResponseEntity<Object> getPermissionsByRoleId(@PathVariable UUID roleId) {
        try {
            List<Permission> permissionIds = roleService.getPermissionsByRoleId(roleId);
            return new ResponseEntity<>(permissionIds, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}