package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.MenuItemRequest;
import com.example.managementservice.service.MenuItemService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/menu-items")
@Tag(name = "Menu Items", description = "APIs for managing menu items in the system")
@RequiredArgsConstructor
public class MenuItemController {

    private final MenuItemService menuItemService;

    @Operation(summary = "Create a new menu item", description = "Creates a new menu item and returns the created item details.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Menu item created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload")
    })
    @PostMapping
    public ResponseEntity<MenuItemRequest> createMenuItem(@RequestBody MenuItemRequest menuItemDto) {
        MenuItemRequest createdMenuItem = menuItemService.createMenuItem(menuItemDto);
        return ResponseEntity.status(201).body(createdMenuItem);
    }

    @Operation(summary = "Get menu item by ID", description = "Fetches a menu item by its unique identifier.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Menu item found"),
            @ApiResponse(responseCode = "404", description = "Menu item not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<MenuItemRequest> getMenuItemById(@PathVariable UUID id) {
        return menuItemService.getMenuItemById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get all menu items", description = "Fetches a list of all available menu items.")
    @ApiResponse(responseCode = "200", description = "List of menu items retrieved successfully")
    @GetMapping
    public ResponseEntity<List<MenuItemRequest>> getAllMenuItems() {
        List<MenuItemRequest> menuItems = menuItemService.getAllMenuItems();
        return ResponseEntity.ok(menuItems);
    }

    @Operation(summary = "Get menu tree", description = "Fetches the menu hierarchy tree structure.")
    @ApiResponse(responseCode = "200", description = "Menu tree retrieved successfully")
    @GetMapping("/tree")
    public ResponseEntity<List<MenuItemRequest>> getMenuTree() {
        List<MenuItemRequest> menuTree = menuItemService.getMenuTree();
        return ResponseEntity.ok(menuTree);
    }

    @Operation(summary = "Update a menu item", description = "Updates an existing menu item and returns the updated details.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Menu item updated successfully"),
            @ApiResponse(responseCode = "404", description = "Menu item not found")
    })
    @PutMapping("/{id}")
    public ResponseEntity<MenuItemRequest> updateMenuItem(@PathVariable UUID id, @RequestBody MenuItemRequest menuItemDto) {
        MenuItemRequest updatedMenuItem = menuItemService.updateMenuItem(id, menuItemDto);
        return ResponseEntity.ok(updatedMenuItem);
    }

    @Operation(summary = "Delete a menu item", description = "Deletes a menu item by its ID.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Menu item deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Menu item not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMenuItem(@PathVariable UUID id) {
        menuItemService.deleteMenuItem(id);
        return ResponseEntity.noContent().build();
    }
}