package com.example.managementservice.controller;

import com.example.managementservice.model.Issue;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class IssueSpecifications {

    public static Specification<Issue> withFilters(
            List<String> statusIds,
            List<UUID> priorityIds,
            List<String> workTypeIds,
            List<String> reporters,
            String assignedTo,
            UUID projectId,
            String sprintId,
            String searchText
    ) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            predicates.add(cb.isFalse(root.get("deleted")));

            if (statusIds != null && !statusIds.isEmpty()) {
                CriteriaBuilder.In<String> inClause = cb.in(root.get("status").get("id"));
                statusIds.forEach(inClause::value);
                predicates.add(inClause);
            }

            if (priorityIds != null && !priorityIds.isEmpty()) {
                CriteriaBuilder.In<UUID> inClause = cb.in(root.get("priorityId").get("priorityId"));
                priorityIds.forEach(inClause::value);
                predicates.add(inClause);
            }

            if (workTypeIds != null && !workTypeIds.isEmpty()) {
                CriteriaBuilder.In<String> inClause = cb.in(root.get("workType").get("id"));
                workTypeIds.forEach(inClause::value);
                predicates.add(inClause);
            }

            if (reporters != null && !reporters.isEmpty()) {
                CriteriaBuilder.In<String> inClause = cb.in(root.get("reporter"));
                reporters.forEach(inClause::value);
                predicates.add(inClause);
            }

            if (assignedTo != null) {
                predicates.add(cb.equal(root.get("assignedTo"), assignedTo));
            }

            if (projectId != null) {
                predicates.add(cb.equal(root.get("projectId").get("projectId"), projectId));
            }

            if (sprintId != null && !sprintId.isBlank()) {
                predicates.add(cb.equal(root.get("sprint").get("id"), sprintId));
            }

            if (searchText != null && !searchText.trim().isEmpty()) {
                String likeSearch = "%" + searchText.toLowerCase() + "%";
                Predicate titleMatch = cb.like(cb.lower(root.get("title")), likeSearch);
                Predicate descriptionMatch = cb.like(cb.lower(root.get("description")), likeSearch);
                Predicate ticketNumberMatch = cb.like(cb.lower(cb.concat(root.get("ticketNumber").as(String.class), "")), likeSearch);
                predicates.add(cb.or(titleMatch, descriptionMatch, ticketNumberMatch));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}