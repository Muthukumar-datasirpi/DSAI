package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.TemplateCreateRequest;
import com.example.managementservice.exchange.request.TemplateUpdateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.TemplateResponse;
import com.example.managementservice.service.impl.TemplateServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/templates")
@RequiredArgsConstructor
@Tag(name = "Template Controller", description = "Controller for managing templates")
public class TemplateController {

    private final TemplateServiceImpl templateService;

    @PostMapping
    @Operation(summary = "Create a new template", description = "Creates a new template with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createTemplate(@Valid @RequestBody TemplateCreateRequest request) {
        templateService.createTemplate(request);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Template created successfully", null));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get template by ID", description = "Retrieves a specific template by its ID.")
    public ResponseEntity<ApiResponseHandler<TemplateResponse>> getTemplateById(@PathVariable String id) {
        TemplateResponse template = templateService.getTemplateById(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Template fetched successfully", template));
    }

    @GetMapping
    @Operation(summary = "Get all templates", description = "Retrieves a list of all templates.")
    public ResponseEntity<ApiResponseHandler<List<TemplateResponse>>> getAllTemplatesForTemplateCategory(@RequestParam String categoryId) {
        List<TemplateResponse> templates = templateService.getAllTemplatesForTemplateCategory(categoryId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Templates fetched successfully", templates));
    }

    @PutMapping
    @Operation(summary = "Update an existing template", description = "Updates the details of an existing template.")
    public ResponseEntity<ApiResponseHandler<Object>> updateTemplate(@RequestBody TemplateUpdateRequest updateRequest) {
        templateService.updateTemplate(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Template updated successfully", null));
    }
}