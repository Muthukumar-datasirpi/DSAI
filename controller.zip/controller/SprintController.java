package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.SprintCreateRequest;
import com.example.managementservice.exchange.request.SprintUpdateRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.PaginatedResponse;
import com.example.managementservice.exchange.response.SprintResponse;
import com.example.managementservice.model.Sprint;
import com.example.managementservice.service.impl.SprintServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/sprint")
@RequiredArgsConstructor
@Tag(name = "Sprint Controller", description = "Controller for managing sprints")
public class SprintController {

    private final SprintServiceImpl sprintService;

    @PostMapping
    @Operation(summary = "Create a new sprint", description = "Creates a new sprint with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createSprint(@RequestBody SprintCreateRequest createRequest) {
        sprintService.createSprint(createRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint created successfully"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get sprint by ID", description = "Retrieves a specific sprint by its ID.")
    public ResponseEntity<ApiResponseHandler<SprintResponse>> getSprintById(@PathVariable String id) {
        SprintResponse sprintResponse = sprintService.getSprintById(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint retrieved successfully", sprintResponse));
    }

    @GetMapping
    @Operation(summary = "Get all sprints for a project", description = "Retrieves a paginated list of all sprints for a specific project with optional filters.")
    public ResponseEntity<ApiResponseHandler<PaginatedResponse<SprintResponse>>> getProjectSprints(@RequestParam UUID projectId, @RequestParam(required = false) Boolean isPlanned, @RequestParam(required = false) String search, @RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "10") int size, @RequestParam(defaultValue = "createdAt") String sortBy, @RequestParam(defaultValue = "desc") String sortDirection) {
        PaginatedResponse<SprintResponse> sprints = sprintService.getSprintsByProject(projectId, isPlanned, search, page, size, sortBy, sortDirection);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "List retrieved successfully", sprints));
    }

    @PutMapping
    @Operation(summary = "Update an existing sprint", description = "Updates the details of an existing sprint.")
    public ResponseEntity<ApiResponseHandler<Sprint>> updateSprint(@RequestBody SprintUpdateRequest updateRequest) {
        sprintService.updateSprint(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint updated successfully"));
    }

    @PutMapping("/{id}/start")
    @Operation(summary = "Start a sprint", description = "Starts the sprint with the given ID.")
    public ResponseEntity<ApiResponseHandler<Sprint>> startSprint(@PathVariable String id) {
        sprintService.startSprint(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint started successfully"));
    }

    @PutMapping("/{id}/complete")
    @Operation(summary = "Complete a sprint", description = "Completes the sprint with the given ID and optionally creates a new sprint.")
    public ResponseEntity<ApiResponseHandler<Sprint>> completeSprint(@PathVariable String id, @RequestParam(required = false) String newSprintId, @RequestParam(required = false) Boolean isNewSprint) {
        sprintService.completeSprint(id, newSprintId, isNewSprint);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint completed successfully"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a sprint", description = "Deletes the sprint with the given ID.")
    public ResponseEntity<Object> deleteSprint(@PathVariable String id){
        sprintService.deleteSprint(id);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Sprint deleted successfully"));
    }
}