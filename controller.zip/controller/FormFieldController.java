package com.example.managementservice.controller;

import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.FormFieldDetails;
import com.example.managementservice.service.impl.FormFieldServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/form-fields")
@RequiredArgsConstructor
@Tag(name = "Form Field Controller", description = "Controller for managing form fields")
public class FormFieldController {

    private final FormFieldServiceImpl formFieldService;

    @GetMapping("/{requestTypeId}")
    @Operation(summary = "Get form fields for a specific request type", description = "Retrieves form fields associated with a given request type ID, optionally filtered by category ID.")
    public ResponseEntity<ApiResponseHandler<FormFieldDetails>> getFormFieldsForRequestType(@PathVariable String requestTypeId, @RequestParam(required = false) String categoryId){
        FormFieldDetails formFields = formFieldService.getFormFieldsForRequestType(requestTypeId, categoryId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Form fields retrieved successfully", formFields));
    }
}