package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.LoginEmailRequestDTO;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.service.AuthService;
import com.example.managementservice.service.UserService;
import com.example.managementservice.utils.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Tag(name = "Auth Controller", description = "APIs for managing authorization flow")
@Slf4j
public class AuthController {
    private final AuthService authService;

    private final UserService userService;

    @Operation(summary = "Generate token with email and password", description = "Generates an authentication token for the user")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Token generated",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = AccessTokenResponse.class))),
            @ApiResponse(responseCode = "401", description = "Invalid credentials")
    })
    @PostMapping("/login")
    public ResponseEntity<Object> generateTokenWithEmail(@Parameter(description = "Login request details. Cannot be null or empty", required = true) @Valid @RequestBody LoginEmailRequestDTO request) {
        log.info("Login successful for email: {}", request.getEmailId());
        return authService.generateTokenWithEmail(request.getEmailId(), request.getPassword());
    }

    @Operation(summary = "Refresh access token", description = "Use the refresh token to obtain a new access token")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Token refreshed successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid refresh token"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("/refresh_token")
    public ResponseEntity<Object> refreshToken(@Parameter(description = "Refresh Token Cannot be null or empty", required = true) @RequestParam String refreshToken) {
        return authService.getAccessTokenFromRefreshToken(refreshToken);
    }

    @Operation(summary = "Logout user", description = "Logout the authenticated user and invalidate their session")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = AppConstants.USER_LOGGED_OUT_SUCCESS),
            @ApiResponse(responseCode = "401", description = "Unauthorized - User is not authenticated"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @GetMapping("/logout")
    public ResponseEntity<Object> logoutUser(@AuthenticationPrincipal Jwt principal) {
        return authService.logoutUser(principal.getClaimAsString(AppConstants.SUB), principal.getClaimAsString(AppConstants.DEVICE_ID));
    }

    @Operation(summary = "Check if first user exists",
            description = "Checks whether there is an existing first user.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Check completed",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = ApiResponseHandler.class))),
                    @ApiResponse(responseCode = "500", description = "Internal server error",
                            content = @Content(mediaType = "application/json"))
            })
    @GetMapping("/first-user")
    public ResponseEntity<ApiResponseHandler> isFirstUser() {
        return userService.findFirstUser();
    }
}