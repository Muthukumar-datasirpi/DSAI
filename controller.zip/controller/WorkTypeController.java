package com.example.managementservice.controller;

import com.example.managementservice.exchange.request.WorkTypeRequest;
import com.example.managementservice.exchange.request.WorkTypeCreateRequest;
import com.example.managementservice.exchange.request.WorkTypeCustomFieldRequest;
import com.example.managementservice.exchange.request.WorkTypeDetailsRequest;
import com.example.managementservice.exchange.response.ApiResponseHandler;
import com.example.managementservice.exchange.response.WorkTypeData;
import com.example.managementservice.exchange.response.WorkTypeDetailsResponse;
import com.example.managementservice.exchange.response.WorkTypeResponse;
import com.example.managementservice.service.impl.WorkTypeServiceImpl;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/work-types")
@RequiredArgsConstructor
@Tag(name = "Work Type Controller", description = "Controller for managing work types")
public class WorkTypeController {

    private final WorkTypeServiceImpl workTypeService;

    @PostMapping
    @Operation(summary = "Create a new work type", description = "Creates a new work type with the provided details.")
    public ResponseEntity<ApiResponseHandler<Object>> createWorkType(@RequestBody WorkTypeCreateRequest workTypeCreateRequest) {
        workTypeService.createWorkType(workTypeCreateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work type created successfully", null));
    }

    /* No usages as of now, but keeping for future use */
    @PostMapping("/custom-field")
    @Hidden
    public ResponseEntity<ApiResponseHandler<Object>> addCustomFieldToWorkType(@RequestBody WorkTypeCustomFieldRequest createRequest) {
        workTypeService.addCustomFieldToWorkType(createRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Custom field added to work type successfully", null));
    }

    @GetMapping
    @Operation(summary = "Get all work type details", description = "Retrieves a list of all work type details.")
    public ResponseEntity<ApiResponseHandler<List<WorkTypeDetailsResponse>>> getAllWorkTypeDetails() {
        List<WorkTypeDetailsResponse> workTypeDetails = workTypeService.getWorkTypeDetails();
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work type details retrieved successfully", workTypeDetails));
    }

    @GetMapping("/{workTypeId}/details")
    @Operation(summary = "Get work type details by ID", description = "Retrieves the details of a specific work type by its ID.")
    public ResponseEntity<ApiResponseHandler<WorkTypeDetailsResponse>> getWorkTypeDetailsById(@PathVariable String workTypeId) {
        WorkTypeDetailsResponse workTypeDetails = workTypeService.getWorkTypeDetailsById(workTypeId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work type details retrieved successfully", workTypeDetails));
    }

    @PutMapping("/details")
    @Operation(summary = "Update work type details", description = "Updates the details of an existing work type.")
    public ResponseEntity<ApiResponseHandler<Object>> updateWorkTypeDetails(@RequestBody WorkTypeRequest updateRequest) {
        workTypeService.updateWorkTypeDetails(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work type details updated successfully", null));
    }

    @GetMapping("/{projectId}/dropdown")
    @Operation(summary = "Get work types for project dropdown", description = "Retrieves a list of work types for a specific project to be used in dropdowns.")
    public ResponseEntity<ApiResponseHandler<List<WorkTypeData>>> getProjectWorkTypes(@PathVariable UUID projectId) {
        List<WorkTypeData> workTypeData = workTypeService.getProjectWorkTypes(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work type data for the specified project retrieved successfully", workTypeData));
    }

    @GetMapping("/{projectId}")
    @Operation(summary = "Get all work types for a project", description = "Retrieves all work types associated with a specific project.")
    public ResponseEntity<ApiResponseHandler<WorkTypeResponse>> getAllWorkTypesForProject(@PathVariable UUID projectId) {
        WorkTypeResponse workTypes = workTypeService.getAllWorkTypesForProject(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work types retrieved successfully", workTypes));
    }

    @PutMapping
    @Operation(summary = "Add or update custom field to work type", description = "Adds or updates a custom field for a specific work type.")
    public ResponseEntity<ApiResponseHandler<Object>> addAndUpdateCustomFieldToWorkType(@RequestBody WorkTypeDetailsRequest updateRequest) {
        workTypeService.addAndUpdateCustomFieldToWorkType(updateRequest);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work type order and details updated successfully", null));
    }

    /* To create work types for a specific project
    *  As this is in development phase this API is needed to create the default work types for the projects that has been created before this implementation
    * No usages after that */
    @PostMapping("/{projectId}")
    @Hidden
    public ResponseEntity<ApiResponseHandler<Object>> createWorkTypesForProjectId(@PathVariable UUID projectId) {
        workTypeService.createWorkTypesForProjectId(projectId);
        return ResponseEntity.ok(new ApiResponseHandler<>(true, "Work types created for project successfully", null));
    }
}